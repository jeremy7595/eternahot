ETERNAHOT.COM — REDESIGN SESSION FILES
July 7, 2026

launch/  — the four launch-ready files to commit to jeremy7595/eternahot (repo root):
  index.html        Homepage (v16 final) — Netlify form "service-request", relative links
  residential.html  Rebuilt in new design system — form "residential-request"
  commercial.html   Rebuilt in new design system — form "commercial-request"
  thank-you.html    Form success page (noindex)

  All four: no pricing anywhere, forms wired for Netlify Forms
  (data-netlify + honeypot), form action -> /thank-you.

design-iterations/ — homepage design history (v2 through v16, plus first draft).
  v16 is the approved final; the rest are for reference only.

DEPLOY ORDER (important):
  1. Commit the 4 launch files to jeremy7595/eternahot (main).
     The repo currently holds the OLD red video-hero site with $149 offers —
     these files replace index.html and thank-you.html and add the other two.
  2. Only THEN link the repo to the Netlify "eternahot" project
     (Configuration > Build & deploy > Link repository; branch main,
     no build command, publish root). Linking triggers an immediate deploy.
  3. After first deploy: check Netlify Forms UI for the three forms,
     test a submission, verify /residential and /commercial load.

POST-LAUNCH TODO:
  - Swap Wikimedia Rinnai logo URL for the official PRO Network asset
    (commit the file to the repo, update <img> srcs).
  - Set real prices in the Specials "Inquire" slots when ready.
  - Confirm competitor-brand list in meta description / JSON-LD.
  - Old site remains in Netlify deploy history for one-click rollback.

Design system: Libre Caslon Display/Text + Libre Franklin · navy #0C1926 ·
porcelain #F5F6F4 · flame gradient #FF7A2F->#FFC24B · CSLB #1150831 ·
(213) 222-3457 · office@eternahot.com · Mo–Sa 7am–6pm.
